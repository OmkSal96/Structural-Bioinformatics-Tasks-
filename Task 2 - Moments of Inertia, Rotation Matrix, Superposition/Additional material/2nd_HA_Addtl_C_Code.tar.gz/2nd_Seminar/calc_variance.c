
/*-----------------------------------*/
 float calc_variance(float *data,int n)
/*-----------------------------------*/
{ float sum_x,sum_xx,sq;
  int i;

 if(n>1)
 {
  sum_x=0.0;sum_xx=0.0;

  for(i=0;i<n;i++) 
 	{ sum_x+=data[i];
          sum_xx+=data[i]*data[i];
        }   
        
  sq=sum_xx-sum_x/(float)n*sum_x;
  sq/=(float)(n);
  


 }
 
 return(sq);
}


