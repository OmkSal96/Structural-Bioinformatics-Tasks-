
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "vector.c"
#include "graphics_2.c"
#include "rotate_2.c"
#include "moments_o_inertia.c"

char *file;
float bond_length[10],beadRad[10];
int num_o_points,LABEL,SORT=1;
float min_dim[3]={1000000.0,1000000.0,10000000.0},*Surface_dots[2],
  max_dim[3]={-1000000.0,-1000000.0,-10000000.0},base_vector[3][3],
  Vec1[2][3],Vec2[2][3],Vec3[2][3],grid,edgeLength,Center[2][3];

int    *HYDROPHOB,NOTRACE,*sortList,start_point=0,nmodels=0,model_start[10],model_nbeads[10],
    Dots,dots[2],SUPERIMP,GRID,RMS,FILL,MOVIE,SUPERIMP,
    SURFACE,bonds_min=0;

float ellip,vec1[2][3],vec2[2][3],vec3[2][3],angle,angle1,pos_ref[3]={0.0,0.0,0.0},FirstVec[3];
char modelName[2][40];
int n_o_models;
struct point_el
{
  float pos[3];
  char atom[10];
  int bonded_to[150];
  int bonds;
  int model;
  int wasDrawn;
};
int MOMENTS=0,CHIRAL=1;


struct point_el *POINT,*POINT_Mirror;



/*----------------------------------*/
 void setBaseVectors()
/*----------------------------------*/
{
/* base vectors according to face centered cubic lattice */
  float origin[3],d,a;

  origin[0]=origin[1]=origin[2]=0.0;
  
    
  base_vector[0][0]=edgeLength;
  base_vector[0][1]=0.0;
  base_vector[0][2]=0.0;


  base_vector[1][0]=edgeLength*cos(60.0*M_PI/180.0);
  base_vector[1][1]=edgeLength*sin(60.0*M_PI/180.0);
  base_vector[1][2]=0.0;

  base_vector[2][0]=edgeLength*cos(60.0*M_PI/180.0);
  base_vector[2][1]=tan(30.0*M_PI/180.0)*0.5*edgeLength;
  base_vector[2][2]=0.0;

  d=distance(origin,base_vector[2]);
  a=acos(d/edgeLength);

  base_vector[2][2]=edgeLength*sin(a);

}







/*------------------------------*/
 void fill()
/*------------------------------*/
{

  edgeLength=bond_length[0]/2.0;
  setBaseVectors();

}





void  generateMirrorImage(struct point_el *P)
{

  int i,m=0,co;

  
  for(i=model_start[m];i<model_start[m]+model_nbeads[m];i++)
    {
      for(co=0;co<3;co++)
	P[i].pos[co]=-P[i].pos[co];
    }
  
}





/*------------------------------*/
 void match()
/*------------------------------*/   
{

  float *pos[2],raxis[3],ROT[3][3],*ptr,tmp_pos[3],rms,rmsMax=0.0;
  int co,i,m,point,cycle,j,k,i_max,j_max,k_max,Cycle,rmsMaxChir1,rmsMaxChir2,takeInvert=0;
  struct point_el *TmpPoint;
  float computeRMS();

  if(CHIRAL)
    Cycle=2;
  else
    Cycle=1;

  if(nmodels==1 && MOMENTS)
    {
      Cycle=1;
      model_nbeads[0]=num_o_points;
    }
     
  
  if(nmodels==2 || (nmodels==1 && MOMENTS))
  {

    for(m=0;m<nmodels;m++)
      {
	pos[m]=(float *)malloc(3*model_nbeads[m]*sizeof(float));
	
	
	for(i=model_start[m];i<model_start[m]+model_nbeads[m];i++)
	  {
	    for(co=0;co<3;co++)
	      pos[m][3*(i-model_start[m])+co]=POINT[i].pos[co];
	  }
	calc_moments_o_inertia(vec1[m],vec2[m],vec3[m],&ellip,pos[m],model_nbeads[m]);

       
	free(pos[m]);
	if(nmodels==1 && MOMENTS)
	  {
	    return;
	  }

	/*
	for(i=0;i<2;i++)
	  {
	    printf("Model %i: vec1 (x,y,z): %f\t%f\t%f\n",m,vec1[m][0],vec1[m][1],vec1[m][2]);
	    printf("Model %i: vec2 (x,y,z): %f\t%f\t%f\n",m,vec2[m][0],vec2[m][1],vec2[m][2]);
	    printf("Model %i: vec3 (x,y,z): %f\t%f\t%f\n",m,vec3[m][0],vec3[m][1],vec3[m][2]);
	  }
	*/

      }


  }
	
	
	

	
	
}








/*------------------------------*/
 float computeRMS()
/*------------------------------*/
{
  int i,j;
  float bond_length2,d;
  int sharedVolume=0,counter;
  float distance_2(float *,float *),length;

  /* quick measure of overlap */
  

  if(bond_length[0]>bond_length[1])
    length=bond_length[0];
  else
    length=bond_length[1];

  
  length/=2.0;
  

  bond_length2=length*length;
  
  for(i=0;i<num_o_points;i++)
  {
    counter=0;
    for(j=0;j<num_o_points;j++)
    {
      
      if(POINT[i].model!=POINT[j].model)
      {
        d=distance_2(POINT[i].pos,POINT[j].pos);
        
	if(d<bond_length2)
	  {
	    sharedVolume++;
	    j=num_o_points;
	  }
      }
      
      
    }
  }

  /*  printf("%f %% overlap\n",100.0*(float)((float)sharedVolume/(float)num_o_points));*/
  return(100.0*(float)((float)sharedVolume/(float)num_o_points));
}





/*------------------------------*/
 void ReadXYZ(char *file_name)
/*------------------------------*/
{
  FILE *in;
  char line[150];
  int i;
  static int first=1,model=0;
  
  
 
  
  if((in=fopen(file_name,"r"))==NULL)
    {
     printf("Could not open %s\n",file_name);
     exit(0);
    }
  else
    printf("Reading lattice from %s\n",file_name);

  fgets(line,149,in);
  sscanf(line,"%i",&num_o_points);
  model_nbeads[nmodels]=num_o_points;
  model_start[nmodels]=start_point;
  
  fgets(line,149,in);
  sscanf(line,"%f %f",&beadRad[model],&bond_length[model]);

  beadRad[model]/=4.0;

  if(first)
  {
    POINT=(struct point_el *)malloc(num_o_points*sizeof(struct point_el));
    sortList=(int *)malloc(num_o_points*sizeof(int));
    first=0;
    
  } else {
    
    POINT=(struct point_el *)realloc(POINT,(start_point+num_o_points)*sizeof(struct point_el));
    sortList=(int *)realloc(sortList,(start_point+num_o_points)*sizeof(int));
  }
  
  for(i=start_point;i<start_point+num_o_points;i++)
  {
    
    fgets(line,149,in);
    sscanf(line,"%s %f %f %f,",POINT[i].atom,
           &POINT[i].pos[0],&POINT[i].pos[1],&POINT[i].pos[2]);
    POINT[i].bonds=0;
    POINT[i].model=model;
    
    sortList[i]=i;
    
  }
  num_o_points=start_point+num_o_points;
  model++;
  
  start_point=i;
  nmodels++;
  
  fclose(in);
  
}


/*----------------------------------------*/
 int compare(const void *a, const void *b)
/*----------------------------------------*/  
{

  float f1=0.0,f2=0.0;
  const int *i=a,*j=b;
  


 
  f1=POINT[*i].pos[2];
  f2=POINT[*j].pos[2];
 
  
  if(f1>f2) return  -1;
  else return 1;

    
}



/*------------*/
 void sort_Z()
/*------------*/   
{
  int i,j,flipped=0,tmp,a,b;

  qsort(sortList,num_o_points,
        sizeof(int),
        compare);

}









/*------------------------------*/
 void Dimensions_and_Center()
/*------------------------------*/  
{
  int i,co,m;
  float center[3]={0.0,0.0,0.0},radius_o_gyration;
  



  for(m=0;m<nmodels;m++)
  {
    center[0]=0.0;
    center[1]=0.0;
    center[2]=0.0;

   
    for(i=model_start[m];i<model_start[m]+model_nbeads[m];i++)
    {
            
      for(co=0;co<3;co++)
      {
        center[co]+=POINT[i].pos[co];

        if(m==nmodels-1)
        {
          if(POINT[i].pos[co]<min_dim[co])
            min_dim[co]=POINT[i].pos[co];
          if(POINT[i].pos[co]>max_dim[co])
            max_dim[co]=POINT[i].pos[co];
        }
      }
    }
    
    for(co=0;co<3;co++)
      {
	
	center[co]/=(float)model_nbeads[m];
	Center[m][co]=center[co];
	
	/*printf("%f\n",center[co]);*/
      }
  }
  

  bottom_z=min_dim[2]-15.0;
  top_z=max_dim[2]+15.0;
  
}



/*----------------------------------------*/
 float distance_2(float *pos1, float *pos2)
/*----------------------------------------*/   
{
  return(((pos1[0]-pos2[0])*(pos1[0]-pos2[0])+
          (pos1[1]-pos2[1])*(pos1[1]-pos2[1])+
          (pos1[2]-pos2[2])*(pos1[2]-pos2[2])));
  


}


/*------------*/
 void Connect()
/*------------*/   
{
  int i,j;
  float bond_length2,d;


  
  for(i=0;i<num_o_points;i++)
  {
    bond_length2=bond_length[POINT[i].model]*bond_length[POINT[i].model];
    
    for(j=i+1;j<num_o_points;j++)
    {
      if(POINT[i].model==POINT[j].model)
      {
        d=distance_2(POINT[i].pos,POINT[j].pos);
        
      if(d<1.1*bond_length2)
      {
       
        POINT[i].bonded_to[POINT[i].bonds]=j;
        POINT[i].bonds++;
	POINT[j].bonded_to[POINT[j].bonds]=i;
	POINT[j].bonds++;

        if(d<0.01)
          printf("%i %i overlap\n",i,j);
      }
      }
      
      
    }
  }


  if(bonds_min==0)
    {

      bonds_min=100000;

      for(i=0;i<num_o_points;i++)
	{
	  
	  
	  if(POINT[i].bonds<bonds_min)
	    {
	      bonds_min=POINT[i].bonds;
	    }
	}
    }



}

                   

  



/*-------------------------------------*/
 void draw(Window win)
/*-------------------------------------*/
{
  int i,j,k;
  static int first=1;
  float tmp[3]={0.0,0.0,0.0};


  if(first)
  {
    sprintf(BackgroundColor,"black");
    setbackground(win,"black");
    init_graded_colors("green");
    init_graded_colors("yellow");
    init_graded_colors("black");
    init_graded_colors("red");
    first=0;
  }




  if(SORT)
    sort_Z();
  
  clear_hidden_window(win);
  
 

  
  for(k=0;k<num_o_points;k++)
  {
    i=sortList[k];
    

    if(POINT[i].bonds>=bonds_min)
      {
	POINT[i].wasDrawn=1;
    
	FillFullCircle_3Dg(win,POINT[i].pos[0]-beadRad[POINT[i].model]/2.0,
			   POINT[i].pos[1]-beadRad[POINT[i].model]/2.0,
			   POINT[i].pos[2]-beadRad[POINT[i].model]/2.0,
			   
			   beadRad[POINT[i].model],
			   bottom_z-0.0,top_z+0.0,
			   
			   POINT[i].model);
	
	circle_3D(win,POINT[i].pos[0]-beadRad[POINT[i].model]/2.0,
		  POINT[i].pos[1]-beadRad[POINT[i].model]/2.0,
		  POINT[i].pos[2]-beadRad[POINT[i].model]/2.0,
		  
		  beadRad[POINT[i].model],
		  bottom_z-0.0,top_z+0.0,
		  
		  2);
	/*
	if(POINT[i].model==0)
	  setLineWidth(1);
	else
	  setLineWidth(2);
	*/
	for(j=0;j<POINT[i].bonds;j++)
	  {
	    if(POINT[POINT[i].bonded_to[j]].bonds>=bonds_min)
	      line_3Dg(win,POINT[i].pos,
		       POINT[POINT[i].bonded_to[j]].pos,
		       bottom_z-0.0,top_z+0.0,POINT[i].model);
	    
	    
	    
	  }
	
	if(LABEL)
	  {
	    
	    
	    outtextXY_3Dg(win, POINT[i].pos[0]+beadRad[POINT[i].model]/1.5,
			  POINT[i].pos[1],
			  POINT[i].pos[2],
			  POINT[i].atom,
			  POINT[i].model);
	  }
      }
    else
      POINT[i].wasDrawn=0;

    if(GRID)
      {
	setcolor(ColorScale[3][2]);
	
	for(i=0;i<20;i++)
	  line(win,(float)(i-10)*grid,
	       0.0,(float)(i-10)*grid,
	       grid/2.0);
	
      }
    
    if(MOMENTS)
      {
	
	setcolor(ColorScale[0][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec1[0][0],20.0*vec1[0][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec2[0][0],20.0*vec2[0][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec3[0][0],20.0*vec3[0][1]);
      
	setcolor(ColorScale[1][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec1[1][0],20.0*vec1[1][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec2[1][0],20.0*vec2[1][1]);
	line(win,pos_ref[0],pos_ref[1],20.0*vec3[1][0],20.0*vec3[1][1]);                                                           
      }            
  }

  if(SURFACE)
  {
    putpixels_3Dg(win,Surface_dots[0],dots[0],bottom_z-0.0,
                                   top_z+0.0,0);
    putpixels_3Dg(win,Surface_dots[1],dots[1],bottom_z-0.0,
                  top_z+0.0,1);     
    }

}

/*---------------------------------------*/
 void buttonmove(Window win)
/*---------------------------------------*/
{
  int x,y,i,button;
  static int x_old=0,y_old=0,ButtoN,ButtoN_delay,first;
  float d_alpha_x=0.0,d_alpha_y=0.0;
  float deltaBonds=0.0;
  Window child,root;
  int    win_x, win_y, root_x,root_y;
  unsigned int key_buttons;


  deltaBonds=0.0;
  
  while(!buttonreleased(win))
  {

  XQueryPointer(display,win,&root,&child,&root_x,&root_y, &x,&y,&key_buttons);

  if(key_buttons&Button1Mask)
    {
      button=256;
      if(key_buttons&ShiftMask)
	{
	  button=257;
	}
    }
  else if(key_buttons&Button2Mask)
    {
      button=512;
      if(key_buttons&ShiftMask)
	{
	  button=513;
	}
    }
 else if(key_buttons&Button3Mask)
    {
      button=1024;
    }



  if(y>15)
  {
    if(NewClick) 
    {
      x_old=x;
      y_old=y;
      NewClick=0;
      first=ButtoN=event.xbutton.button;
      
      goto cont;
    }
    else
    {
      d_alpha_x=5.0*(float)(x-x_old)/(float)Width*M_PI;
      d_alpha_y=5.0*(float)(y-y_old)/(float)Width*M_PI;
    }
    
    
    

    
    
    switch(button)
    {
      case 256:
      {    

        if(y<Height-20)
        {
          if(SURFACE)
          {
            rotate(win,X,Surface_dots[0],dots[0],-d_alpha_x,0);
            rotate(win,X,Surface_dots[1],dots[1],-d_alpha_x,0);
            
            rotate(win,Y,Surface_dots[0],dots[0],d_alpha_y,0);
            rotate(win,Y,Surface_dots[1],dots[1],d_alpha_y,0);
          }
	  
	  rotate(win,0,vec1[0],1,-d_alpha_x,0);
	  rotate(win,0,vec1[1],1,-d_alpha_x,0);

	  rotate(win,0,vec2[0],1,-d_alpha_x,0);
	  rotate(win,0,vec2[1],1,-d_alpha_x,0);

	 
	  rotate(win,0,vec3[0],1,-d_alpha_x,0);
	  rotate(win,0,vec3[1],1,-d_alpha_x,0);
	 
	  rotate(win,1,vec1[0],1,d_alpha_y,0);
	  rotate(win,1,vec1[1],1,d_alpha_y,0);

	  rotate(win,1,vec2[0],1,d_alpha_y,0);
	  rotate(win,1,vec2[1],1,d_alpha_y,0);

	  rotate(win,1,vec3[0],1,d_alpha_y,0);
	  rotate(win,1,vec3[1],1,d_alpha_y,0);

          
          for(i=0;i<num_o_points;i++) 
            rotate(win,0,POINT[i].pos,1,-d_alpha_x,0);
          
          for(i=0;i<num_o_points-1;i++) 
            rotate(win,1,POINT[i].pos,1,d_alpha_y,0);  
          rotate(win,1,POINT[num_o_points-1].pos,1,d_alpha_y,1);
        } else {
          if(SURFACE)
          {
            rotate(win,Z,Surface_dots[0],dots[0],-d_alpha_x,0);
            rotate(win,Z,Surface_dots[1],dots[1],-d_alpha_x,0);
            rotate(win,Z,Surface_dots[0],dots[0],d_alpha_y,0);
            rotate(win,Z,Surface_dots[1],dots[1],d_alpha_y,0);
          }
	
	 
	  rotate(win,2,vec1[0],1,-d_alpha_x,0);
	  rotate(win,2,vec1[1],1,-d_alpha_x,0);

	  rotate(win,2,vec2[0],1,-d_alpha_x,0);
	  rotate(win,2,vec2[1],1,-d_alpha_x,0);

	  rotate(win,2,vec3[0],1,-d_alpha_x,0);
	  rotate(win,2,vec3[1],1,-d_alpha_x,0);
	  
          for(i=0;i<num_o_points;i++) 
            rotate(win,Z,POINT[i].pos,1,-d_alpha_x,0);
          rotate(win,Z,POINT[0].pos,1,0.0,1);
          
        }
        
        break; 
        
      }

      
      case 257:
      {    


        if(y>Height-20)
        {
	  rotate(win,2,vec1[0],1,-d_alpha_x,0);
	  rotate(win,2,vec2[0],1,-d_alpha_x,0);
	  rotate(win,2,vec3[0],1,-d_alpha_x,0);           
	  
          rotate(win,2,Surface_dots[0],dots[0],-d_alpha_x,0);
          for(i=0;i<model_nbeads[0];i++) 
            rotate(win,2,POINT[i].pos,1,-d_alpha_x,0);

          rotate(win,2,POINT[0].pos,1,0.0,1);
          
        } else {

	  rotate(win,0,vec1[0],1,-d_alpha_x,0);
	  rotate(win,0,vec2[0],1,-d_alpha_x,0);
	  rotate(win,0,vec3[0],1,-d_alpha_x,0);
	  
	 
	  rotate(win,1,vec1[0],1,d_alpha_y,0);
	  rotate(win,1,vec2[0],1,d_alpha_y,0);
	  rotate(win,1,vec3[0],1,d_alpha_y,0);

          rotate(win,X,Surface_dots[0],dots[0],-d_alpha_x,0);
          for(i=0;i<model_nbeads[0];i++) 
            rotate(win,0,POINT[i].pos,1,-d_alpha_x,0);
          
          rotate(win,Y,Surface_dots[0],dots[0],d_alpha_y,0);
          for(i=0;i<model_nbeads[0]-1;i++) 
            rotate(win,1,POINT[i].pos,1,d_alpha_y,0);  
          rotate(win,1,POINT[model_nbeads[0]-1].pos,1,d_alpha_y,1);
        }
        
        
        break; 
        
      }
      
      
      case 512:
      {      
        translate(win,x-x_old,y-y_old);
        break;
        
      }
      case 513:
      {
        for(i=0;i<model_nbeads[0];i++)
        {
         
          
          POINT[i].pos[0]+=(float)((float)(x-x_old)/5.0);
          POINT[i].pos[1]+=((float)(float)(y-y_old)/5.0);
          
        
          
        }
        
        

        
        draw(map);
        show_hidden_window(map,win);
        
        break;
        
      }
        
      
      case 1024:
      {      
        
        if(x<Width-15){ if(y!=y_old) zoom(win,y<y_old);}
        else
          zoom_font(win,font_name,y<y_old);
        break;    
      }
      case 768:
      { if(y!=y_old) slab_thick(win,y<y_old);
      break;    
      }
      
      case 1536:
      { if(y!=y_old) slab_shift(win,y<y_old);
      break;    
      }
      
    }
    
    
    
    
    
    
    
    
    cont: 1==1;
    
    x_old=x;
    y_old=y;
    
    
  }
  }

NewClick=1;
}




/*------------------*/
 void writeXYZ()
/*------------------*/
{
  FILE *out;
  int i,notDrawn=0;
  char name[100];


  printf("writing to xlattice_supimp.xyz\n");
  

  out=fopen("xlattice_supimp.xyz","w");
  

  for(i=0;i<num_o_points;i++)
  {
    if(!POINT[i].wasDrawn)
      notDrawn++;
  }

  fprintf(out,"%i\n",num_o_points-notDrawn);
  fprintf(out,"%f %f\n",bond_length[0],bond_length[0]);
  
  for(i=0;i<num_o_points;i++)
  {

   if(POINT[i].wasDrawn)
     fprintf(out,"C%i %8.3f %8.3f %8.3f\n",i,
	     POINT[i].pos[0],
	     POINT[i].pos[1],
	     POINT[i].pos[2]);

    
    
  }

  fclose(out);
  


}


/*---------------------------------------*/
 void buttonpress(Window win)
/*---------------------------------------*/
{
   int x,y;
   float rms;

   x=event.xmotion.x;
   y=event.xmotion.y;
   
  if(x<10 && y<10)
  {
    XCloseDisplay(display);
    exit(1);
  }
  if(x>Width-10 && y<10)
    sort_Z();
  
  if(x>Width-10 && y>Height-10)
    writeXYZ();
  if(x<10 && y>Height-10)
    {
      if(event.xbutton.button==3)
	{
	  Dimensions_and_Center();
	  update(win);
	}
      printf("%f %% overlap\n",computeRMS());  
    }
  
}



/*-----------------------------------*/
 void buttonrelease(Window win) 
/*-----------------------------------*/
{}




main(int argc, char **argv)
{
  Window win=NULL;
  char line[500];
  int i;
  char options[500],*p;
  float rms;

  for(i=1;i<argc;i++)
  {
    sprintf(options,"%s %s",options,argv[i]);
  }
  if(argc<2 || strstr(options," -h"))
    {
      printf("\nXlattice v990315, Author: Dr Dirk Walther (UCSF)\n\n");
      printf("\nusage: command model1.xyz [model2.xyz]\n");
      printf("\n\tmaximally two structures at a time, extension '.xyz' required\n");
      printf("\n\tFormat of xyz-file:\n");
      printf("\n\t\t%%i (number_of_beads)\n");
      printf("\t\t%%f %%f (bead_radius  considered_as_bonded_cutoff_length)\n");
      printf("\t\t%%s %%f %%f %%f (label x-coord y-coord z-coord)\n");
      printf("\t\t.\n");
      printf("\t\t.\n");
      printf("\t\t.\n");
      printf("\nOptions\n\t-rms\tcalculate overlap (in percent) only, no display\n");
      printf("\t-grid\t<GridSpacing>\n\t\tdisplay ruler with ticks separated at GridSpacing Angstroms\n");
      printf("\t-nosup\tno superposition upon invokation of program\n");
      printf("\t\tif structures are too big, superposition may take a long time.\n");
      printf("\t-f\t<min number of bonds>\n\t\tapply filter by requiring that a bead\n\t\thas at least <min number of bonds> within <considered_as_bonded_cutoff_length>,\n\t\tpurpose: filtering of superimposed models (contrast enhancement)\n");
      printf("\t-label\tshow labels\n");
      printf("\t-nochir\tdon't check mirror image when superimposing\n");

      printf("\n\tMouse actions:\n\n");
      printf("\t\tleft: rotate\n");
      printf("\t\tmiddle: translate\n");
      printf("\t\tshift+above: apply to only one model if two are loaded\n");
      printf("\t\tright: zoom\n");
      printf("\n\t\tshift+right: filter in/decrease (drag vertically)\n");
     
      printf("\t\tleft+middle: adjust drawing slab width\n");
      printf("\t\tright+middle: shift drawing slab in z-direction\n");
      printf("\n\tinvisible corner-buttons:\n\n");
      printf("\t\tupper left corner: exit\n");
      printf("\t\tlower left corner:\n");
      printf("\t\t\tleft mouse button: calculate overlap in percent\n");
      printf("\t\t\tright mouse button: superimpose models\n");
      printf("\t\tlower right corner: write current model to file named xlattice_supimp.xyz\n");
      
      exit(0);

    }

  if(strstr(options,"-label")) LABEL=1;  else LABEL=0;


  if(strstr(options,"-nosort")) SORT=0;  else SORT=1;
  if(strstr(options,"-moments")) MOMENTS=1; else MOMENTS=0;
  if(strstr(options,"-rms")) RMS=1; else RMS=0;
  if(strstr(options,"-movie")) MOVIE=1; else MOVIE=0; 
  if(strstr(options,"-nosup")) SUPERIMP=0; else SUPERIMP=1; 
  if(strstr(options,"-nochir")) CHIRAL=0; else CHIRAL=1; 


  if((p=strstr(options," -f"))!=NULL)
    sscanf(p+3,"%i",&bonds_min);

  if((p=strstr(options," -grid"))!=NULL)
    {
      GRID=1;
      
      sscanf(p+6,"%f",&grid);
      printf("tick spacing=%f A\n",grid);
  }
  else GRID=0;
  
  /* file=argv[1]; */

  sprintf(line,"Xlattice : ");
  for(i=1;i<argc;i++)
  {
    if(strstr(argv[i],".xyz"))
      {
	ReadXYZ(argv[i]);
	sprintf(modelName[n_o_models],"%s",argv[i]);
	n_o_models++;
	sprintf(line,"%s %s ",line,argv[i]);

      }
  }

  Dimensions_and_Center();
  Connect();
  /*match();*/
  
  if(nmodels==2 && SUPERIMP)
    {
      if(RMS)
	{
	  printf("%f %%overlap\n",computeRMS());

	  for(i=0;i<num_o_points;i++)
	    {
	      POINT[i].wasDrawn=1;
	    }

	  writeXYZ();
	}
      
    }


if(!RMS)
  Window_and_Call_Draw(win,line,min_dim[0]-2.0,min_dim[0]-2.0,
                       max_dim[0]+2.0,max_dim[0]+2.0,500,500);

}
