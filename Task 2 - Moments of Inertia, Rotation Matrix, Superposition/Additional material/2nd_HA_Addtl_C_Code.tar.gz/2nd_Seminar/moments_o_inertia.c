
#include "calc_variance.c"

#ifndef  RECIPE

#include "nrutil.c"
#include "jacobi.c"
#include "eigsrt.c"
#define  RECIPE TRUE
# endif


float Orientation(float *positions,int n,float *center,float *vec)
{
  float tmp_moment_vec[3],tmp_vec2[3],*pos,*neg,sc,v1,v2;
  int i,pos_counts=0,neg_counts=0,p,j;


  pos=(float *)malloc(n*sizeof(float));
  neg=(float *)malloc(n*sizeof(float));

  for(i=0;i<3;i++)
    tmp_moment_vec[i]=vec[i];

  NORM_VECTOR(tmp_moment_vec);
  
  for(p=0;p<n;p++)
    {
      for(i=0;i<3;i++)
	tmp_vec2[i]=positions[3*p+i]-center[i];
      
      sc=SCALAR_PRODUCT(tmp_vec2,tmp_moment_vec);
      if(sc>0.0)
	{
	 
	  pos[pos_counts]=sc;
	  pos_counts++;
	}
      else
	{
	  neg[neg_counts]=sc;
	  neg_counts++;
	}

    }
  
  
  v1=calc_variance(pos,pos_counts);
  v2=calc_variance(neg,neg_counts); 
  
  return((v1>v2)?1.0:-1.0);



}


/*--------------------------------------------------------------*/
 void calc_moments_o_inertia( float *vect1,
			      float *vect2,
			      float *vect3,
                              float *ellip,
			      float *positions,int n_o_positions)
/*--------------------------------------------------------------*/
{
 float x,y,z,
       eigenvalues[4],**eigenvectors,max_d,dn,
       center_p[3],tmp_v[3],
       **inertia_tensor;

 int i,*indx,nrot,j;

 inertia_tensor=(float **)malloc((unsigned)4*sizeof(float *));
 eigenvectors =(float **)malloc((unsigned)4*sizeof(float *));
 for(i=0;i<4;i++) {inertia_tensor[i]=(float *)malloc((unsigned)4*sizeof(float));
                   eigenvectors[i]=(float *)calloc(4,sizeof(float));
		 }
 
 
 for(i=0;i<4;i++)
   {  
     for(j=0;j<4;j++) 
       inertia_tensor[i][j]=0.0;
   }
 


 center_p[0]=0.0;
 center_p[1]=0.0;
 center_p[2]=0.0;         



for(i=0;i<n_o_positions;i++)
 {
  center_p[0]+=positions[3*i];
  center_p[1]+=positions[3*i+1];
  center_p[2]+=positions[3*i+2];         
 
 }


 center_p[0]/=(float)n_o_positions;
 center_p[1]/=(float)n_o_positions;
 center_p[2]/=(float)n_o_positions;


 for(i=0;i<n_o_positions;i++)
  {         
    x=positions[3*i]-center_p[0];
    y=positions[3*i+1]-center_p[1];
    z=positions[3*i+2]-center_p[2];
    
    inertia_tensor[1][1]+= (y*y+z*z);            
    inertia_tensor[2][2]+= (x*x+z*z);
    inertia_tensor[3][3]+= (x*x+y*y);
    
    inertia_tensor[1][2]-=x*y;
    inertia_tensor[1][3]-=x*z;
    inertia_tensor[2][3]-=y*z;
    
    inertia_tensor[2][1]-=x*y;
    inertia_tensor[3][1]-=x*z;
    inertia_tensor[3][2]-=y*z;
  }
 

jacobi(inertia_tensor,3,eigenvalues,eigenvectors,&nrot);
eigsrt(eigenvalues,eigenvectors,3);


/*
printf("\neigenvalues %f %f %f\n\n",eigenvalues[1],eigenvalues[2],eigenvalues[3]);


printf("%f %f %f\n",  eigenvectors[1][1],eigenvectors[1][2],eigenvectors[1][3]);
printf("%f %f %f\n",  eigenvectors[2][1],eigenvectors[2][2],eigenvectors[2][3]);
printf("%f %f %f\n\n",eigenvectors[3][1],eigenvectors[3][2],eigenvectors[3][3]);
*/




 vect1[0]=eigenvalues[1]/eigenvalues[1]*eigenvectors[1][1]; 
 vect1[1]=eigenvalues[1]/eigenvalues[1]*eigenvectors[2][1]; 
 vect1[2]=eigenvalues[1]/eigenvalues[1]*eigenvectors[3][1];

 vect2[0]=eigenvalues[2]/eigenvalues[1]*eigenvectors[1][2]; 
 vect2[1]=eigenvalues[2]/eigenvalues[1]*eigenvectors[2][2]; 
 vect2[2]=eigenvalues[2]/eigenvalues[1]*eigenvectors[3][2]; 

 vect3[0]=eigenvalues[3]/eigenvalues[1]*eigenvectors[1][3]; 
 vect3[1]=eigenvalues[3]/eigenvalues[1]*eigenvectors[2][3]; 
 vect3[2]=eigenvalues[3]/eigenvalues[1]*eigenvectors[3][3];


 /*
 if(Oriented_Angle_between_vectors(vect2,vect3,vect1)<0.0)
   SCALAR_TIMES_VECTOR(-1.0,vect3);
 */
 /* define directions according to skewness of distribution */

 /*

 SCALAR_TIMES_VECTOR(Orientation(positions,n_o_positions,center_p,vect1),vect1);
 SCALAR_TIMES_VECTOR(Orientation(positions,n_o_positions,center_p,vect2),vect2);
 SCALAR_TIMES_VECTOR(Orientation(positions,n_o_positions,center_p,vect3),vect3);
 */




 *ellip=(float)(eigenvalues[3]/(  (eigenvalues[1]+eigenvalues[2])/2.0 ));


}





