#define X 0
#define Y 1
#define Z 2

float ROT_MAT[3][3];

/*------------------------------------------------*/
 void ROTATION_MATRIX(float Angle,float *ROT_AXIS)
/*------------------------------------------------*/
{

float COS,SIN,lm,nl,mn,l,m,n,_cos;

         
        COS=cos(Angle);
        SIN=sin(Angle);

        _cos=1.0-COS;

        l=ROT_AXIS[X];
        m=ROT_AXIS[Y];
        n=ROT_AXIS[Z];
 
        lm=l*m; 
        nl=l*n; 
        mn=m*n; 


   ROT_MAT[0][0]=_cos*l*l +COS;
   ROT_MAT[0][1]=_cos*lm-n*SIN;
   ROT_MAT[0][2]=_cos*nl+m*SIN;


   ROT_MAT[1][0]=_cos*lm+n*SIN;
   ROT_MAT[1][1]=_cos*m*m +COS;
   ROT_MAT[1][2]=_cos*mn-l*SIN;

   ROT_MAT[2][0]=_cos*nl-m*SIN;
   ROT_MAT[2][1]=_cos*mn+l*SIN;
   ROT_MAT[2][2]=_cos*n*n +COS;


}
                      
                      

 






/*--------------------------------------------------------------------------------*/
  void ROTATE_around(float *pos_ref,float *rot_pos, float *rot_axis, float d_angle)
/*--------------------------------------------------------------------------------*/
{ float  POS[3];

  



 NORM_VECTOR(rot_axis);


 ROTATION_MATRIX(d_angle,rot_axis);



rot_pos[X]-=pos_ref[X];
rot_pos[Y]-=pos_ref[Y];
rot_pos[Z]-=pos_ref[Z];

  POS[X]= rot_pos[X]*ROT_MAT[0][0]+
          rot_pos[Y]*ROT_MAT[1][0]+
          rot_pos[Z]*ROT_MAT[2][0];

  POS[Y]= rot_pos[X]*ROT_MAT[0][1]+
          rot_pos[Y]*ROT_MAT[1][1]+
          rot_pos[Z]*ROT_MAT[2][1]; 

  POS[Z]= rot_pos[X]*ROT_MAT[0][2]+
          rot_pos[Y]*ROT_MAT[1][2]+
          rot_pos[Z]*ROT_MAT[2][2];

rot_pos[X]= POS[X]+pos_ref[X];
rot_pos[Y]= POS[Y]+pos_ref[Y];
rot_pos[Z]= POS[Z]+pos_ref[Z];
 
}


