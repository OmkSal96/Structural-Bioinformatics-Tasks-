
#include<stdio.h>
#include<math.h>
#include<time.h>

# include "vector.c"
# include "graphics_2.c"
# include "least_square_plane.c" 
# include "distance_from_least_square_plane.c" 

#define RANDOM_MAX 2147483647.0
#define random_number random()/RANDOM_MAX

float moment_vectors[18],position[10000],d;
int *HYDROPHOB,n_o_points;



/*-----------------------------------------------------------*/
float Dev_From_Plane(float *face_positions, int n_o_face_pos)
/*-----------------------------------------------------------*/
{
  float x,y,z,
    eigenvalues[4],**eigenvectors,max_d,dn,
    center_p[3],
    **inertia_tensor;

  int i,*indx,nrot,j;

  inertia_tensor=(float **)malloc((unsigned)4*sizeof(float *));
  eigenvectors =(float **)malloc((unsigned)4*sizeof(float *));
  for(i=0;i<4;i++) {inertia_tensor[i]=(float *)malloc((unsigned)4*sizeof(float));
  eigenvectors[i]=(float *)calloc(4,sizeof(float));
  }
 
 
  for(i=0;i<4;i++)
  {  for(j=0;j<4;j++) inertia_tensor[i][j]=0.0;
  }
 


  center_p[0]=0.0;
  center_p[1]=0.0;
  center_p[2]=0.0;         


  for(i=0;i<n_o_face_pos;i++)
  {
    center_p[0]+=face_positions[3*i];
    center_p[1]+=face_positions[3*i+1];
    center_p[2]+=face_positions[3*i+2];         
 
  }


  center_p[0]/=(float)n_o_face_pos;
  center_p[1]/=(float)n_o_face_pos;
  center_p[2]/=(float)n_o_face_pos;
 




  for(i=0;i<n_o_face_pos;i++)
  {         x=face_positions[3*i]-center_p[0];
  y=face_positions[3*i+1]-center_p[1];
  z=face_positions[3*i+2]-center_p[2];

  inertia_tensor[1][1]+= (y*y+z*z);            
  inertia_tensor[2][2]+= (x*x+z*z);
  inertia_tensor[3][3]+= (x*x+y*y);
             
  inertia_tensor[1][2]-=x*y;
  inertia_tensor[1][3]-=x*z;
  inertia_tensor[2][3]-=y*z;

  inertia_tensor[2][1]-=x*y;
  inertia_tensor[3][1]-=x*z;
  inertia_tensor[3][2]-=y*z;
  }


  jacobi(inertia_tensor,3,eigenvalues,eigenvectors,&nrot);
  eigsrt(eigenvalues,eigenvectors,3);



  printf("\nEigen values: %f %f %f\n\n",eigenvalues[1],eigenvalues[2],eigenvalues[3]);

  printf("%f %f %f\n",  eigenvectors[1][1],eigenvectors[1][2],eigenvectors[1][3]);
  printf("%f %f %f\n",  eigenvectors[2][1],eigenvectors[2][2],eigenvectors[2][3]);
  printf("%f %f %f\n\n",eigenvectors[3][1],eigenvectors[3][2],eigenvectors[3][3]);





/* for graphics */
  j=0;
  for(i=0;i<3;i++)
  { 
    moment_vectors[j++]=center_p[0];
    moment_vectors[j++]=center_p[1];
    moment_vectors[j++]=center_p[2];
    
    
    moment_vectors[j++]=center_p[0]+30.0*eigenvalues[i+1]/eigenvalues[1]*eigenvectors[1][i+1];
    moment_vectors[j++]=center_p[1]+30.0*eigenvalues[i+1]/eigenvalues[1]*eigenvectors[2][i+1];
    moment_vectors[j++]=center_p[2]+30.0*eigenvalues[i+1]/eigenvalues[1]*eigenvectors[3][i+1]; 
    
  }


  d=0.0;
  max_d= -1000.0;

  for(i=0;i<n_o_face_pos;i++)
  {         x=face_positions[3*i]  -center_p[0];
  y=face_positions[3*i+1]-center_p[1];
  z=face_positions[3*i+2]-center_p[2];

  dn=fabs(eigenvectors[1][1]*x+
          eigenvectors[2][1]*y+
          eigenvectors[3][1]*z);
           
  d+=dn*dn;

  if(dn>max_d) max_d=dn;
  }

  d/=(float)n_o_face_pos;
  d=sqrt(d);
  printf("d =  %f max = %f \n",d,max_d);

  printf("%f %f %f\n",center_p[0],center_p[1],center_p[2]);

 

  return(eigenvalues[3]/eigenvalues[1]);


}



/*-----------------------------*/
void draw(Window win)
/*-----------------------------*/
{

  int i,j;
  static int first=1;

  if(first)
  { first=0;
  init_graded_colors("white");
  init_graded_colors("red");
  }
  setcolor(Color("yellow"));



 
 

  putpixels_3Dg(win,position,n_o_points,-50,50,0);
  for(i=0;i<3;i++)
    lines_3Dg(win,&moment_vectors[i*6],2,-50.0,50.0,1);


}




void buttonpress(Window win) 
{ 

   int x,y;
   float angle;

   x=event.xmotion.x;
   y=event.xmotion.y;

   if(x>Width/2)
     {
       angle=-0.03;
     }
   else
     {
       angle=0.03;
     }

  setbackground(win,"black");
  while(!buttonreleased(win))
    {
      
      
      switch(event.xbutton.button)
	{case Button1:
	    {
	      rotate(win,0,position,n_o_points,angle,0);
	      rotate(win,0,moment_vectors,6,angle,1);
	      break;
	    }
	case Button2:
	  {rotate(win,1,position,n_o_points,angle,0);
	    rotate(win,1,moment_vectors,6,angle,1);
	    break;
	  }
	case Button3:
	  {rotate(win,2,position,n_o_points,angle,0);
	    rotate(win,2,moment_vectors,6,angle,1);
	    break;
	  }
	}
      //printf("\n%f\n",Dev_From_Plane(position,n_o_points));
    } 
}


void buttonrelease(Window win) {}

void buttonmove(Window win) {}


main(int argc, char **argv)
{
  Window win;
  float max[3];
  float center[3],e,vec1[3],vec2[3],vec3[3];
  int i;
  char value[10];

  if(argc<2)
    {
      printf("\nUsage: a.out dim_x dim_y dim_z, example: a.out 70 70 10\n");
      exit(0);
    }

  sprintf(value,"%s",argv[1]);
  sscanf(value,"%f",&max[0]);
  sprintf(value,"%s",argv[2]);
  sscanf(value,"%f",&max[1]);
  sprintf(value,"%s",argv[3]);
  sscanf(value,"%f",&max[2]);

  srandom(time(0));

  n_o_points=2000;

  for(i=0;i<3*n_o_points;i+=3)
  { 
    position[i]=  (random_number-0.5)*max[0];
    position[i+1]=(random_number-0.5)*max[1];  
    position[i+2]=(random_number-0.5)*max[2];  
  }

  printf("\n%f\n",Dev_From_Plane(position,n_o_points));

  


  e=least_square_plane(vec1,vec2,vec3,position,n_o_points);
  printf("\n---> %f\n",sqrt(e));

  e=distance_from_least_square_plane(position,n_o_points);
  printf("\n--new-> %f\n",e);


  Window_and_Call_Draw(win,"least square plane",-50.0,-50.0,50.0,50.0,600,600);






}



