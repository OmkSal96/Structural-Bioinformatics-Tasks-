#include<stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <math.h>


#define BITMAPDEPTH   1
#define TOO_SMALL     0
#define BIG_ENOUGH    1
#define defaultGC     DefaultGC(display,screenNumber)
#define screenNumber  DefaultScreen(display)
#define rootWindow    RootWindow(display,screenNumber)
#define displayHeight DisplayHeight(display,screenNumber)
#define displayWidth  DisplayWidth(display,screenNumber)
#define blackPixel    BlackPixel(display,screenNumber)
#define whitePixel    WhitePixel(display,screenNumber)
#define borderWidth   1
#define defaultcmap   DefaultColormap(display,screenNumber)
#define defaultDepth  XDefaultDepth(display,screenNumber)
#define windowX       (displayWidth/3)
#define windowY       (displayHeight/3)
#define Button        event.xbutton.button
#define grades        25
#define n_o_shadow_colors 10


XEvent          event;
Display        *display;
unsigned int    Width, Height;
float           maxX,maxY,X1,Y1,X2,Y2,bottom_z,top_z;
unsigned long  *Scale;
float           ratioX,ratioY; 
unsigned long  *ColorScale[10],backgroundpixel,
                RAINBOW[300][3];

Font            font;               
Pixmap          map;
int bits[8]={1,2,4,8,16,32,64,128},Z_BUFFERING=0,FRAME=0,linewidth;
static float font_size_float=12.0;
float z_slab_bottom, z_slab_top;
char *hex={"0123456789abcdef"},BackgroundColor[50];
int  FrameColor,NOFRAME=0,SHADOW=0,NewClick=1;
char DISPLAY[20],font_name[100];


/*---------------------------------*/
 unsigned long Color(char *string)
/*---------------------------------*/
{ XColor colorstruct;

 XParseColor(display,defaultcmap,string,&colorstruct);
 XAllocColor(display,defaultcmap,&colorstruct);
 return(colorstruct.pixel);
}



/*-------------------------------------------*/
 void setbackground(Window win,char *string)
/*-------------------------------------------*/
{ XSetWindowBackground(display,win,Color(string));
  backgroundpixel = Color(string);
  XClearWindow(display,win);
} 


/*-------------------------------------------*/
 void setlinewidth(int width)
/*-------------------------------------------*/
{ 
 XSetLineAttributes(display,defaultGC,width,
                     LineSolid,CapRound,JoinRound);
}

/*-----------------------------------*/
 int buttonreleased(Window win)
/*-----------------------------------*/
{  
  return(XCheckWindowEvent(display,win,
                   ButtonReleaseMask,
                   &event));
}



/*-----------------------------------*/
 int buttonpressed(Window win)
/*-----------------------------------*/
{  
  return(XCheckWindowEvent(display,win,
                   ButtonPressMask,
                   &event));
}




/*------------------------------------------------------------------------------*/
 unsigned long Colorgraded(char *string, float grad, int to_black)
/*------------------------------------------------------------------------------*/
{ static XColor colorstruct,colorstruct_back,colorstruct_black,
                colorstruct_new;
  static int first=1;
  static char string_old[20];



 if(first)
   {
    XParseColor(display,defaultcmap,BackgroundColor,&colorstruct_back);
    XParseColor(display,defaultcmap,"black",&colorstruct_black);
    XParseColor(display,defaultcmap,string,&colorstruct);
    first=0;
   } 

 if(strcmp(string,string_old) !=0 ) 
   XParseColor(display,defaultcmap,string,&colorstruct);


 
if(!to_black)
  {
  
  colorstruct_new.red  = colorstruct_back.red  
                    -(int)((float)(grad*(float)((float)colorstruct_back.red-(float)colorstruct.red)));
  colorstruct_new.blue = colorstruct_back.blue 
                    -(int)((float)(grad*(float)((float)colorstruct_back.blue-(float)colorstruct.blue)));
  colorstruct_new.green= colorstruct_back.green
                    -(int)((float)(grad*(float)((float)colorstruct_back.green-(float)colorstruct.green)));


 
  /*
  colorstruct_new.red=(int)(grad*65535);
  colorstruct_new.blue=(int)(grad*65535);
  colorstruct_new.green=(int)(grad*65535);
  */
  }
else
  {
 

  colorstruct_new.red  = colorstruct.red;  
  colorstruct_new.blue = colorstruct.blue; 
  colorstruct_new.green= colorstruct.green;

/*
  colorstruct_new.red  = colorstruct_black.red  
                    -(int)((float)((float)grad)*(colorstruct_black.red  -colorstruct.red));
  colorstruct_new.blue = colorstruct_black.blue 
                    -(int)((float)((float)grad)*(colorstruct_black.blue -colorstruct.blue));
  colorstruct_new.green= colorstruct_black.green
                    -(int)((float)((float)grad)*(colorstruct_black.green-colorstruct.green));

*/
 }
  



  sprintf(string_old,"%s",string);

  XAllocColor(display,defaultcmap,&colorstruct_new); 

  return(colorstruct_new.pixel);


}




/*----------------------------------------------*/
 void init_graded_colors(char *string)
/*----------------------------------------------*/
{ static int counter=0;
  int i,j;
 
  
 if(SHADOW)
  { ColorScale[counter]=(unsigned long *)(malloc((grades+3)*n_o_shadow_colors
                                                *sizeof(unsigned long)));
    for(i=0;i<=grades*n_o_shadow_colors;i++)
       { ColorScale[counter][i]=Colorgraded(string,(float)(grades*n_o_shadow_colors-i)
                                                    /(float)(grades*n_o_shadow_colors),0);
       
       for(j=1;j<n_o_shadow_colors-n_o_shadow_colors;j++) 
      
          {/* ColorScale[counter][i+j]=Colorgraded(string,
                                               (float)(j)/
                                               (float)n_o_shadow_colors,1);*/
             ColorScale[counter][i+j]=Colorgraded(string,(float)(grades*n_o_shadow_colors-i)
                                                    /(float)(grades*n_o_shadow_colors),0);
           
        
	 }
       }
  }

 else
   {
     ColorScale[counter]=(unsigned long *)(malloc((grades+1)*sizeof(unsigned long)));
     
     for(i=0;i<=grades;i++)
       {
	 ColorScale[counter][i]=Colorgraded(string,(float)((float)(grades-i)/(float)grades),0); 
	 /*printf("%i %f %f\n",i,(float)((float)(grades-i)/(float)grades),(float)ColorScale[counter][i]);*/
       }
   }



  counter++;
}      
         





/*-------------------------------------------------*/
 void win_dim(Window win)
/*-------------------------------------------------*/
{
 
 
  Width= event.xconfigure.width;
  Height=event.xconfigure.height;
 
  ratioX=maxX/(float)Width;
  ratioY=maxY/(float)Height;
  
}



/*------------------------------------------------------------------------*/
 void setcolor_light(unsigned long i,float *vec)
/*------------------------------------------------------------------------*/
{
 unsigned long i_new;
 float angle;
 static float z_vec[3];
 static int first=1;
 extern float Angle_between_lines(float *, float*);



 if(first) { first=0; 
             z_vec[0]=0.0; z_vec[1]=0.0; z_vec[2]=1.0;
           }
 

           
 angle=fabs(M_PI-Angle_between_lines(z_vec,vec))/M_PI;

 printf("%f %f %f\n %f %f %f\n\n",z_vec[0],z_vec[1],z_vec[2],
                                vec[0],vec[1],vec[2]);
/*
 i_new=i*n_o_shadow_colors+(int)(angle* (float)(n_o_shadow_colors-1));  
*/

 

i_new=(unsigned int)((i*n_o_shadow_colors)+1);    

 printf("%f %i %i\n\n\n",angle,i,i_new);

 XSetForeground(display,defaultGC,i_new);


}




/*---------------------------------------*/
 void setcolor(unsigned long i)
/*---------------------------------------*/
{
 if(SHADOW) i*=n_o_shadow_colors;
 XSetForeground(display,defaultGC,i);

}




/*---------------------------------------*/
 void setfont(char *font_name)
/*---------------------------------------*/
{
font = XLoadFont(display,font_name);
XSetFont(display,defaultGC,font);

}




/*--------------------------------*/
 void line(Window win,
                  float x1,
                  float y1,
                  float x2,
                  float y2)
/*--------------------------------*/
{
   XDrawLine(display,win,defaultGC,
   (int)(0.5+(x1-X1)/ratioX),
   (int)(0.5+(y1-Y1)/ratioY),
   (int)(0.5+(x2-X1)/ratioX),
   (int)(0.5+(y2-Y1)/ratioY));
}

/*------------------------------------------------------------------------*/
 void lines_3D(Window win,float *point, int npoints)
/*------------------------------------------------------------------------*/
{ int i;
  
  for(i=0;i<(3*(npoints-1));i+=3)
    {   
       line(win,point[i],point[i+1],
                point[i+3],point[i+4]);
    }
}  

/*------------------------------------------------------------------------*/
 void lines_3Dg(Window win,float *point, int npoints,
               float zu,float zo,int color )
/*------------------------------------------------------------------------*/
{ int i, grad,j;
  static int grad_old;
  float z_diff,middle,vector[3];

  z_diff=zo-zu;

    for(i=0;i<(3*(npoints-1));i+=3)
    {middle=(point[i+2]+point[i+5])/2.0; 
     if(middle> z_slab_bottom && middle<z_slab_top && 
        middle>zu && middle<zo)
     { 
       grad=(int)((middle-zu)/(z_diff)*grades);
      


       if(FRAME && !NOFRAME) { 
		       
                  
                     setlinewidth(linewidth+2);
                    
                     setcolor(ColorScale[FrameColor][grad]);
                 
                     line(win,point[i],point[i+1],
                     point[i+3],point[i+4]);
                     
                     if(SHADOW)
		       { for(j=0;j<3;j++) vector[j]=point[i+3+j]-point[i+j];
                         setcolor_light(ColorScale[color][grad],vector);
   
		       }
                     else setcolor(ColorScale[color][grad]);    
                    
                    
                     setlinewidth(linewidth);

	             line(win,point[i],point[i+1],
		     point[i+3],point[i+4]);
		      
		  }
    
       else
	 { if(SHADOW)
		       { for(j=0;j<3;j++) vector[j]=point[i+3+j]-point[i+j];
                         setcolor_light(ColorScale[color][grad],vector);
                         printf("> %f %f %f\n",vector[0],vector[1],vector[2]); 
		       }
           else 
	                 setcolor(ColorScale[color][grad]);                 

	   line(win,point[i],point[i+1],
		point[i+3],point[i+4]);
         }
     }
        
    }
   
     
}  


/*------------------------------------------------------------------------*/
 void line_3Dg(Window win,float *point1, float *point2,
               float zu,float zo,int color )
/*------------------------------------------------------------------------*/
{ int i, grad,j;
  static int grad_old;
  float z_diff,middle,vector[3];
  
 
  z_diff=zo-zu;
  middle= (point1[2]+point2[2])/2.0;   
      if(middle>z_slab_bottom && middle<z_slab_top
         && middle>zu && middle<zo)
      {
      grad=(int)((middle-zu)/(z_diff)*grades);
       if(grad<0) grad=0;
       if(grad>grades) grad=grades-1;
    
 
         if(FRAME && !NOFRAME) {
		      
                    
                     setlinewidth(linewidth+2);
                     setcolor(ColorScale[FrameColor][grad]);    
             
                     line(win,point1[0],point1[1],
                     point2[0],point2[1]);                     

                   
                     setlinewidth(linewidth);

                     if(SHADOW)
		       { for(j=0;j<3;j++) vector[j]=point2[j]-point1[j];
                         setcolor_light(ColorScale[color][grad],vector);
                       }
                     else

                      setcolor(ColorScale[color][grad]);                 

	             line(win,point1[0],point1[1],
		     point2[0],point2[1]);
		      
            
		  }
    
       else
	 {  if(SHADOW)
		       { for(j=0;j<3;j++) vector[j]=point2[j]-point1[j];
                         setcolor_light(ColorScale[color][grad],vector);
                        
                       }
                     else
		       {
		
	                setcolor(ColorScale[color][grad]);     
		       }


	    line(win,point1[0],point1[1],
		point2[0],point2[1]);
         }
      
        
        
       
      
     }



    


}











/*------------------------------------------------------------------------*/
 void putcross_3Dg(Window win,float *point,float dx,float dy, 
               float zu,float zo,int color )
/*------------------------------------------------------------------------*/
{ int i, grad;
  void putpixel(Window,double, double);
   
  float z_diff;
 
  z_diff=zo-zu;
  
      if(point[2]>z_slab_bottom && point[2]<z_slab_top &&
         point[2]>zu && point[2]<zo )
      {
       grad=(int)((point[2]-zu)/(z_diff)*grades);
       if(grad<0) grad=grades-1;
       if(grad>=grades) grad=grades-1;  
       
       setcolor(ColorScale[color][grad]);
     
       
       line(win,point[0]-dx,point[1],
		point[0]+dx,point[1]);
       line(win,point[0],point[1]-dy,
		point[0],point[1]+dy); 
     }
    
   
     
}  





/*------------------------------------------------------------------------*/
 void putpixels_3Dg(Window win,float *point, int npoints,
               float zu,float zo,int color )
/*------------------------------------------------------------------------*/
{ int i, grad;
  void putpixel(Window,double, double);
   
  float z_diff;
 
  z_diff=zo-zu;
  
    for(i=0;i<(3*npoints);i+=3)
    { if(point[i+2]>z_slab_bottom && point[i+2]<z_slab_top &&
         point[i+2]>zu && point[i+2]<zo )
      {
       grad=(int)((point[i+2]-zu)/(z_diff)*grades);
       if(grad<0) grad=grades-1;
       if(grad>=grades) grad=grades-1;  
       
       setcolor(ColorScale[color][grad]);
       
       
       
       putpixel(win,point[i],point[i+1]);
     }
    }
   
     
}  

/*------------------------------------------------------------------------*/
 void putpixels_3Dg_hydro(Window win,float *point, int npoints,
               float zu,float zo,int color1, int color2 )
/*------------------------------------------------------------------------*/
{ int i, grad,color;
  void putpixel(Window,double, double);
  extern int *HYDROPHOB;
  static int grad_old,color_old;
  float z_diff;
  
  z_diff=zo-zu;

    for(i=0;i<(3*npoints);i+=3)
    { if(point[i+2]>z_slab_bottom && point[i+2]<z_slab_top &&
         point[i+2]>zu && point[i+2]<zo )
      {
       grad=(int)((point[i+2]-zu)/(z_diff)*grades);
       if(grad<0) grad=grades-1;
       if(grad>=grades) grad=grades-1;
       if(HYDROPHOB[i/3]==1) color=color1; else color=color2;
        
       setcolor(ColorScale[color][grad]);
      
        
       putpixel(win,point[i],point[i+1]);
     }
    }


}






/*------------------------------------------------------------------------*/
 void putpixels_3Dg_slab(Window win,float *point, int npoints,
               float zu,float zo,float slab_u, float slab_o,int color )
/*------------------------------------------------------------------------*/
{ int i, grad;
  void putpixel(Window,double, double);
  static int grad_old;
  
 
    for(i=0;i<(3*npoints);i+=3)
    {  

      if(point[i+2]>z_slab_bottom && point[i+2]<z_slab_top &&
         point[i+2]>zu && point[i+2]<zo )
      {

       if(point[i+2]>slab_u && point[i+2]< slab_o) 
       {
        grad=(int)((point[i+2]-zu)/(zo-zu)*grades); 
        if(grad<0) grad=grades-1;
        if(grad>=grades) grad=grades-1;   
        
         setcolor(ColorScale[color][grad]);
        
       
        
        putpixel(win,point[i],point[i+1]);
       }
     }
    }
   
     
}  



/*-----------------------------*/
void lines(Window win, 
            float *point,
            int npoints)
/*-----------------------------*/
{ 
  XPoint *Points;
  int i,j;
   
  Points=(XPoint *)malloc(2*sizeof(unsigned long)*npoints); 
  
  j=0;
  for(i=0;i<(2*npoints);i+=2)
    {Points[j].x=(int)(0.5+(point[i]-X1)/ratioX);
     Points[j++].y=(int)(0.5+(point[i+1]-Y1)/ratioY);
    }
  XDrawLines(display,win,defaultGC,Points,npoints,CoordModeOrigin);
  free(Points); 

}



void fillrectangle(Window win,
                       float x1,
                       float y1,
                       float x2,
                       float y2)
{
  XFillRectangle(display,win,defaultGC,
                 (int)(0.5+(x1-X1)/ratioX),
                 (int)(0.5+(y1-Y1)/ratioY),
                 (int)(x2/ratioX),
                 (int)(y2/ratioY));
  }





/*-------------------------------------*/
void rectangle(Window win,
                       float x1,
                       float y1,
                       float x2,
                       float y2)
/*-------------------------------------*/
 {
  XDrawRectangle(display,win,defaultGC,
  (int)(0.5+(x1-X1)/ratioX),
  (int)(0.5+(y1-Y1)/ratioY),
  (int)(x2/ratioX),
  (int)(y2/ratioY)); 
 }


/*--------------------------------------*/ 
  void circle(Window win,float x,
                         float y,
                         float diameter)
/*--------------------------------------*/
{           
  XDrawArc(display,win,defaultGC,
     (int)(0.5+(x-X1)/ratioX),
     (int)(0.5+(y-Y1)/ratioY),
     (int)(0.5+(diameter)/fabs(ratioX)),
     (int)(0.5+(diameter)/fabs(ratioY)),
     23040,23040); 

  
}

/*--------------------------------------*/
  void circle_3D(Window win,
                         float x,
                         float y,
                         float z,
                         float diameter,
                         float zu, float zo,
                         int color)
/*--------------------------------------*/
{int grad;

  if(z>z_slab_bottom && z<z_slab_top && z>zu && z<zo)
  {
  grad=(int)(
       (z-zu)/(zo-zu)*grades);
       if(grad<0) grad= grades-1; /* 0; */
       if(grad>=grades)
         grad=grades-1;
       setcolor(ColorScale[color][grad]);
  XDrawArc(display,win,defaultGC,
     (int)(0.5+(x-X1)/ratioX),
     (int)(0.5+(y-Y1)/ratioY),
     (int)(0.5+(diameter)/ratioX),
     (int)(0.5+(diameter)/ratioY),
     23040,23040); 
  }

}







/*--------------------------------------*/ 
  void DrawArc(Window win,float x,
                         float y,
                         float radius,
                         float angle1,
                         float angle2)
/*--------------------------------------*/
{           
  XDrawArc(display,win,defaultGC,
     (int)(0.5+((x-radius)-X1)/ratioX),
     (int)(0.5+((y-radius)-Y1)/ratioY),
     (int)(0.5+(2.0*radius)/fabs(ratioX)),
     (int)(0.5+(2.0*radius)/fabs(ratioY)),
    
     (int)(angle1*64.0),(int)(angle2*64.0)); 
 
}

/*------------------------------------------*/
 void FillFullCircle(Window win,float x,
                         float y,
                         float diameter)
/*------------------------------------------*/
{
 XFillArc(display,win,defaultGC,
     (int)(0.5+(x-X1)/ratioX),
     (int)(0.5+(y-Y1)/ratioY),
     (int)(0.5+(diameter)/fabs(ratioX)),
     (int)(0.5+(diameter)/fabs(ratioY)),
     23040,23040); 
}

/*------------------------------------------*/
 void FillFullCircle_3Dg(Window win,float x,
                         float y,float z,
                         float diameter,
                         float zu,float zo,
                         int color)
/*------------------------------------------*/
{int grad;

  if(z>z_slab_bottom && z<z_slab_top && z>zu && z<zo)
  {
  grad=(int)(
       (z-zu)/(zo-zu)*grades);
       if(grad<0) grad= grades-1; /* 0; */
       if(grad>=grades) grad=grades-1;
      
 setcolor(ColorScale[color][grad]);

 XFillArc(display,win,defaultGC,
     (int)(0.5+(x-X1)/ratioX),
     (int)(0.5+(y-Y1)/ratioY),
     (int)(0.5+(diameter)/fabs(ratioX)),
     (int)(0.5+(diameter)/fabs(ratioY)),
     23040,23040); 
  }
}
 



/*------------------------------------*/
  void outtextXY(Window window,
                        float x,
                        float y,
                        char *string)
/*------------------------------------*/
{
  XDrawString(display,window,defaultGC,
    (int)(0.5+(x-X1)/ratioX),
    (int)(0.5+(y-Y1)/ratioY),
    string,strlen(string));
}

/*------------------------------------*/
  void outcharXY(Window window,
                        float x,
                        float y,
                        char letter)
/*------------------------------------*/
{
  char s[2];
  

  sprintf(s,"%c",letter);

  XDrawString(display,window,defaultGC,
    (int)(0.5+(x-X1)/ratioX),
    (int)(0.5+(y-Y1)/ratioY),
    s,1);
}




/*------------------------------------*/
  void outtextXY_3Dg(Window window,
                        float x,
                        float y,
                        float z,
                        
                        char *string,
                        int color)
/*------------------------------------*/
{
 int grad; 

 float zu,zo;

 zu=bottom_z;
 zo=top_z;

 
 if(z>z_slab_bottom && z<z_slab_top && z>zu && z<zo)
   {

    grad=(int)(
       (z-zu)/(zo-zu)*grades);
       if(grad<0) grad= grades-1; /* 0; */
       if(grad>=grades) grad=grades-1;
       setcolor(ColorScale[color][grad]);

    XDrawString(display,window,defaultGC,

    (int)(0.5+(x-X1)/ratioX),
    (int)(0.5+(y-Y1)/ratioY),
    string,strlen(string));
  }
}




/*------------------------------------------*/
 void putpixel(Window win,
               double x,
               double y)
/*------------------------------------------*/
{ 
  XDrawPoint(display,win,defaultGC,
  (int)(0.5+(x-X1)/ratioX),
  (int)(0.5+(y-Y1)/ratioY));
}




/*------------------------------------------*/
 void z_buffering(Window win)
/*------------------------------------------*/
{
  int i; 
  float slices=500.0;
  extern void draw(Window);
 

  XClearWindow(display,win);
  FRAME=1;

  for(i=(int)slices;i>=0;i--)
    {  z_slab_bottom=bottom_z+(float)i*(top_z-bottom_z)/slices;
       z_slab_top   =bottom_z+(float)(i+1)*(top_z-bottom_z)/slices;
       draw(win);

     }
 z_slab_bottom= -1.0e35;
 z_slab_top   =  1.0e35;
 FRAME=0;

}








/*-------------------------------------------*/
  Pixmap hidden_window(Window win)
/*-------------------------------------------*/
{
 Pixmap hidden;
 void clear_hidden_window(Pixmap);
 
 hidden=XCreatePixmap(display,win,
                   displayWidth,displayHeight,defaultDepth);
 
  
 

 clear_hidden_window(hidden);
 return(hidden);
}

/*-------------------------------------*/
 void clear_hidden_window(Pixmap hidden)
/*-------------------------------------*/
{  
 XSetForeground(display,defaultGC,backgroundpixel);
 XFillRectangle(display, hidden, defaultGC, 0, 0,
                Width, Height);  
 XSetForeground(display,defaultGC,whitePixel); 


}





/*-----------------------------------------------*/
 void show_hidden_window(Pixmap hidden, Window win)
/*-----------------------------------------------*/
{
 XCopyArea(display,hidden,win,defaultGC,
           0,0,Width,Height,0,0);
}






/*---------------------------------------------------------*/
 void translate( Window win, int shift_x,int shift_y)
/*---------------------------------------------------------*/
{
 extern void draw(Window);
 float Xtmp1,Xtmp2,Ytmp1,Ytmp2; 
  
  clear_hidden_window(map);



  Xtmp1     =(float)shift_x*fabs(X2-X1)/(float)Width;
  Xtmp2     =(float)shift_x*fabs(X2-X1)/(float)Width;
  
  
  Ytmp1     =(float)shift_y*fabs(Y2-Y1)/(float)Height;
  Ytmp2     =(float)shift_y*fabs(Y2-Y1)/(float)Height;
  
  X1-=Xtmp1;
  X2-=Xtmp2;
  Y1-=Ytmp1;
  Y2-=Ytmp2;
  
 
  draw(map);
  show_hidden_window(map,win);


}

/*---------------------------------------------------*/
 void zoom_font(Window win,char *font_name,int in_out)
/*---------------------------------------------------*/
{
 int font_size;
 Font  font;
 float factor;
 extern void draw(Window);
 char font_new[100];



if(in_out) factor=1.05; else     factor=0.95;




  {  font_size_float*=factor;



    if(font_size_float>24.0) {font_size=24;goto cont;}
    if(font_size_float>18.0) {font_size=18;goto cont;}
    if(font_size_float>14.0) {font_size=14;goto cont;}
    if(font_size_float>12.0) {font_size=12;goto cont;}
    if(font_size_float>10.0) {font_size=10;goto cont;}
    if(font_size_float> 0.0)  {font_size= 8;goto cont;}


  cont:


   if(font_size_float<8.0)  font_size_float=8.0;
   if(font_size_float>24.0) font_size_float=24.0;
 

   sprintf(font_new,"%s%i",font_name,font_size);

   font = XLoadFont(display,font_new);
   XSetFont(display,defaultGC,font);




   clear_hidden_window(map);
   draw(map);
   show_hidden_window(map,win);

 }


}





/*-------------------------------------*/
 void zoom(Window win, int in_out)
/*-------------------------------------*/
{ 
 extern void draw(Window);
 float mean_x, mean_y,factor;
 


 clear_hidden_window(map);
 
 if(in_out>0) factor=0.9;
 else         factor=1.1;


 mean_x=(X1+X2)/2.0; mean_y=(Y1+Y2)/2.0;
  
 X1=mean_x-factor*fabs(mean_x-X1); 
 X2=mean_x+factor*fabs(mean_x-X2);
 Y1=mean_y-factor*fabs(mean_y-Y1); 
 Y2=mean_y+factor*fabs(mean_y-Y2);
  

 maxX=(X2-X1); maxY=(Y2-Y1);
  
 ratioX=maxX/(float)Width;
 ratioY=maxY/(float)Height;
 draw(map);
 show_hidden_window(map,win);


}


/*-------------------------------------*/
 void zoom_x(Window win, int in_out)
/*-------------------------------------*/
{ 
 extern void draw(Window);
 float mean_x, mean_y,factor;
 


 clear_hidden_window(map);



 if(in_out>0) factor=0.95;
 else         factor=1.05;

 
 mean_x=(X1+X2)/2.0; mean_y=(Y1+Y2)/2.0;

 X1=mean_x-factor*fabs(mean_x-X1); 
 X2=mean_x+factor*fabs(mean_x-X2);


 maxX=fabs(X2-X1); maxY=fabs(Y2-Y1);

 ratioX=maxX/(float)Width;
 ratioY=maxY/(float)Height;
 draw(map);
 show_hidden_window(map,win);


}


/*-------------------------------------------------*/
 void zoom_y_refY(Window win, int in_out,float refY)
/*-------------------------------------------------*/
{ 
 extern void draw(Window);
 float mean_x, mean_y,factor;
 


 clear_hidden_window(map);



 if(in_out>0) factor=0.95;
 else         factor=1.05;

 
 mean_x=(X1+X2)/2.0; 
 /*mean_y=(Y1+Y2)/2.0;*/
 mean_y=refY;

 Y1=mean_y-factor*fabs(mean_y-Y1); 
 Y2=mean_y+factor*fabs(mean_y-Y2);

 maxX=fabs(X2-X1); maxY=fabs(Y2-Y1);

 ratioX=maxX/(float)Width;
 ratioY=maxY/(float)Height;
 draw(map);
 show_hidden_window(map,win);


}




/*-------------------------------------------------*/
  void reset_slab(Window win, float *object, int N)
/*-------------------------------------------------*/
{int i;
 
 extern void draw(Window);

 clear_hidden_window(map);

 bottom_z= 10000000.0, top_z= -10000000.0;

 for(i=0;i<N;i++)
  { if(object[3*i+2]<bottom_z) bottom_z= object[3*i+2];
    if(object[3*i+2]>top_z)    top_z=    object[3*i+2];
  }


 draw(map);
 show_hidden_window(map,win);

}









/*------------------------------------*/
 void slab_thick(Window win,int in_out)
/*------------------------------------*/
{  extern void draw(Window);
  
   float z1; 


 z1=bottom_z; 

 clear_hidden_window(map);

    if(in_out>0)
      {z1      =fabs(top_z-bottom_z)/20.0;
       top_z   +=z1;
 
       bottom_z-=z1;
      
     }
    else
      {
       z1      =fabs(top_z-bottom_z)/20.0;
       top_z   -=z1;
 
       bottom_z+=z1;
      
     }
   
    
 draw(map);
 show_hidden_window(map,win);


}


/*------------------------------------*/
 void slab_shift(Window win,int in_out)
/*------------------------------------*/
{  extern void draw(Window);
  
   float z1; 


 z1=bottom_z; 

 clear_hidden_window(map);

    if(in_out>0)
      {z1      =fabs(top_z-bottom_z)/20.0;
       top_z   -=z1;
 
       bottom_z-=z1;
      
     }
    else
      {
       z1      =fabs(top_z-bottom_z)/20.0;
       top_z   +=z1;
 
       bottom_z+=z1;
      
     }
   
    
 draw(map);
 show_hidden_window(map,win);


}




/*---------------------------------*/
 void invert(Window win)
/*---------------------------------*/
{ static int FLAG=1;
  extern void draw(Window);
  float tmp_v;

 

  if(FLAG>0)XSetWindowBackground(display,win,whitePixel);
  else      XSetWindowBackground(display,win,blackPixel);     
  

  
  XClearWindow(display,win);

  draw(win);
 
  FLAG*= -1;
}


/*---------------------------------*/
 void setDisplay(char *d)
/*---------------------------------*/
{
  sprintf(DISPLAY,"%s",d);
}
/*---------------------------------*/
 void update(Window win)
/*---------------------------------*/
{
  extern void draw(Window);
  draw(map);
  show_hidden_window(map,win);
}


/*---------------------------------------------------------*/
 void Window_and_Call_Draw(Window win,
                      char *name, float x1, float y1,
                      float x2,float y2,
                      unsigned int width,
                      unsigned int height)
/*---------------------------------------------------------*/
{

extern void draw(Window);
extern void buttonpress(Window);
extern void buttonmove(Window);
extern void buttonrelease(Window);
int i;


X1=x1; X2=x2; Y1=y1; Y2=y2;
Width=width; Height=height;
maxX=(X2-X1); maxY=(Y2-Y1);
z_slab_bottom= -1.0e20;
z_slab_top   =  1.0e20;



if(!(display = XOpenDisplay(DISPLAY)))
   { fprintf(stderr,"Can't open display\n");
     exit(0);
   }
XFreeColormap(display,defaultcmap);

win = XCreateSimpleWindow(
          display,
          rootWindow,
          windowX,
          windowY, 
          Width, 
          Height,
          borderWidth,
          blackPixel,
          blackPixel);



XSelectInput(display,
             win,
             ButtonPressMask|ButtonReleaseMask|ExposureMask
             |StructureNotifyMask);
 

XStoreName(display,win,name);
 
XMapWindow(display, win);

map=hidden_window(win);



if(strstr(BackgroundColor,"black")==NULL) setbackground(win,BackgroundColor);
else setbackground(win,"black"); 



XSetForeground(display,defaultGC,whitePixel);


/* win_dim(win); */


 
while(1)
{
  XNextEvent(display,&event);
  switch(event.type)
  {

    case Expose:
    { 
     if(event.xexpose.count==0)
     {
     /* XClearWindow(display,win); */    
   
     draw(win);
   
     }
     break;  
    }

    case ConfigureNotify:
    {
        win_dim(win);
        break;
    }

      case ButtonPress:
      { 
        buttonmove(win);       
	buttonpress(win);
        break;
      }
    case ButtonRelease:
     { buttonrelease(win);  
       break;
      }
 
  }  

}
}




/*--------------------------------------------------------------*/
 void rotate(Window win, int axis,
             float *coord, int npoints, float A,int DRAW)
/*--------------------------------------------------------------*/
{ static int FLAG=1;
  int i,B;
  float x;
  static float SIN,COS;
  extern void draw(Window);




 
             
  if(DRAW) clear_hidden_window(map);

  SIN=sin(A); COS=cos(A);


  for(i=0;i<(3*npoints);i+=3)
  {
    switch(axis)
    { case 0: 
      {
       x= coord[i]*COS+
          coord[i+2]*SIN; 
       coord[i+2]= -coord[i]*SIN+
          coord[i+2]*COS;
       coord[i]=x;
      break;
      }
   case 1:
     {
       x=coord[i+1]*COS-
         coord[i+2]*SIN ;
       coord[i+2]=coord[i+1]*SIN+
         coord[i+2]*COS ;
       coord[i+1]=x;
      break;
     }

   case 2:
     {
       x=coord[i]*COS-
         coord[i+1]*SIN ;
       coord[i+1]= coord[i]*SIN+
         coord[i+1]*COS ;
       coord[i]=x;
      break;
     }
   }
 }

if(DRAW)
{ draw(map);
  show_hidden_window(map,win);
}



}































