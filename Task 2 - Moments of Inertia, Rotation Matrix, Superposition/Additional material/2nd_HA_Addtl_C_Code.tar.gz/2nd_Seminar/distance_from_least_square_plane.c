# ifndef  RECIPE
 # include "/home/pub/Num.Recipes/2nd-ed/nrutil.c"
 # include "/home/pub/Num.Recipes/2nd-ed/jacobi.c"
 # include "/home/pub/Num.Recipes/2nd-ed/eigsrt.c"
 # define  RECIPE TRUE
# endif



/* returns the mean square deviation of the positions from the least square plane 
   see Goodfellow JM, Moss DS  "Computer Modelling of Biomolecular Processes" */




/*-------------------------------------------------------------------------*/
 float distance_from_least_square_plane(float *positions,int n_o_positions)
/*-------------------------------------------------------------------------*/
{
 float x,y,z,
       eigenvalues[4],**eigenvectors,max_d,dn,
       center[3],
       sum[3],sum_sq[3],sum_xy,sum_xz,sum_yz,
       **tensor;

 int i,*indx,nrot,j;

 tensor=(float **)malloc((unsigned)4*sizeof(float *));
 eigenvectors =(float **)malloc((unsigned)4*sizeof(float *));
 for(i=0;i<4;i++) {tensor[i]=(float *)malloc((unsigned)4*sizeof(float));
                   eigenvectors[i]=(float *)calloc(4,sizeof(float));
		 }
 
 
 for(i=0;i<4;i++)
   {  for(j=0;j<4;j++) tensor[i][j]=0.0;
    }


 for(i=0;i<3;i++) {sum[i]=0.0; sum_sq[i]=0.0;}
 sum_xy=0.0; sum_xz=0.0; sum_yz=0.0;




 for(i=0;i<3;i++) center[i]=0.0;

 for(i=0;i<n_o_positions;i++)
  {for(j=0;j<3;j++) center[j]+=positions[3*i+j]; 
                    
  }

 for(i=0;i<3;i++) center[i]/=(float)n_o_positions; 




for(i=0;i<n_o_positions;i++)
  {
     for(j=0;j<3;j++)
     {  sum[j]   +=positions[3*i+j]-center[j];
        sum_sq[j]+= (positions[3*i+j]-center[j]) * (positions[3*i+j]-center[j]) ;
     }

        sum_xy+=(positions[3*i]-center[0])  * (positions[3*i+1]-center[1]) ;
        sum_xz+=(positions[3*i]-center[0])  * (positions[3*i+2]-center[2]) ;
        sum_yz+=(positions[3*i+1]-center[1])* (positions[3*i+2]-center[2]) ;
  }




    
        
    for(j=1;j<=3;j++) tensor[j][j]=sum_sq[j-1]/(float)n_o_positions-
		                  ((sum[j-1]/n_o_positions) * (sum[j-1]/n_o_positions));            
           
            tensor[1][2]=tensor[2][1]=sum_xy/n_o_positions-sum[0]*sum[1]/n_o_positions/n_o_positions;
            tensor[1][3]=tensor[3][1]=sum_xz/n_o_positions-sum[0]*sum[2]/n_o_positions/n_o_positions;
            tensor[2][3]=tensor[3][2]=sum_yz/n_o_positions-sum[1]*sum[2]/n_o_positions/n_o_positions;

  






jacobi(tensor,3,eigenvalues,eigenvectors,&nrot);
eigsrt(eigenvalues,eigenvectors,3);




return(sqrt(eigenvalues[3]));
}










